<?php

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'comments',
        'user' => 'ivalekstest',
        'password' => 'Yu_zefREG5EEdTX',
    ],
    'ApplicationOptions' => [
        'template' => 'default',
        'language' => 'RU',
    ],
];
