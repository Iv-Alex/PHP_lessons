<?php

return [
    'db' => [
        'host' => 'localhost',
        'dbname' => 'vanomi_comments',
        'user' => 'vanomi_comments',
        'password' => 'Yu_zefREG5EEdTX',
    ],
    'ApplicationOptions' => [
        'template' => 'default',
        'language' => 'RU',
    ],
];
