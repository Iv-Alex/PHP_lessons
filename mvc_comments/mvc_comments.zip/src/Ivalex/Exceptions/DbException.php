<?php

namespace Ivalex\Exceptions;

class DbException extends \Exception
{
}
