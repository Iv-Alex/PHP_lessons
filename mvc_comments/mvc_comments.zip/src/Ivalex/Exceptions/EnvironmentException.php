<?php

namespace Ivalex\Exceptions;

class EnvironmentException extends \Exception
{
}
