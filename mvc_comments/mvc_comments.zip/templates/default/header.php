<div class="d-flex ">
    <div class="logo">
        <a href="/" title="HoneyHunters zzzzzzzz"><img src="/images/logo.png" alt="HoneyHonters logo"></a>
    </div>
</div>